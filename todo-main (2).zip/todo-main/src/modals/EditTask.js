// EditTask.js

import React, { useState, useEffect } from 'react';
import { Modal, Box, TextField, Button, Typography } from '@mui/material';

const EditTask = ({ modal, toggle, updateTask, taskObj }) => {
    const [taskName, setTaskName] = useState('');
    const [taskDescription, setTaskDescription] = useState('');

    useEffect(() => {
        setTaskName(taskObj.Name);
        setTaskDescription(taskObj.Description);
    }, [taskObj]);

    const handleUpdate = (e) => {
        e.preventDefault();
        let tempObj = {};
        tempObj["Name"] = taskName;
        tempObj["Description"] = taskDescription;
        updateTask(tempObj);
        toggle();
    }

    return (
        <Modal
            open={modal}
            onClose={toggle}
        >
            <Box sx={{ width: 400, margin: 'auto', mt: '10%', padding: 2, backgroundColor: 'white', borderRadius: 1 }}>
                <Typography variant="h6" component="h2">
                    Edit Task
                </Typography>
                <form noValidate autoComplete="off">
                    <TextField
                        fullWidth
                        margin="normal"
                        label="Task Name"
                        value={taskName}
                        onChange={(e) => setTaskName(e.target.value)}
                    />
                    <TextField
                        fullWidth
                        margin="normal"
                        label="Task Description"
                        value={taskDescription}
                        onChange={(e) => setTaskDescription(e.target.value)}
                    />
                    <Button variant="contained" color="primary" onClick={handleUpdate}>
                        Update
                    </Button>
                </form>
            </Box>
        </Modal>
    );
};

export default EditTask;
