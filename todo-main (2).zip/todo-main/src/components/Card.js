// Card.js

import React, { useState } from 'react';
import { Card, CardHeader, CardContent, Button, Typography, Checkbox } from '@mui/material';
import EditTask from '../modals/EditTask';
import '../styles/Card.css';

const CardComponent = ({ taskObj, index, deleteTask, updateListArray, getCategoryColor }) => {
    const [modal, setModal] = useState(false);

    const toggle = () => {
        setModal(!modal);
    }

    const updateTask = (obj) => {
        updateListArray(obj, index);
    }

    const handleDelete = () => {
        deleteTask(index);
    }

    const handleComplete = () => {
        const updatedTask = { ...taskObj, completed: !taskObj.completed };
        updateTask(updatedTask);
    }

    const categoryColor = getCategoryColor(taskObj.category); // 카테고리에 따른 색상 설정

    return (
        <Card className="card-wrapper">
            <div className="card-top" style={{ backgroundColor: categoryColor }}></div>
            <div className="task-holder" style={{ textDecoration: taskObj.completed ? 'line-through' : 'none' }}>
                <span className="card-header" style={{ backgroundColor: categoryColor }}>{taskObj.Name}</span>
                <Typography variant="body2" className="mt-3">
                    {taskObj.Description}
                </Typography>
                <div className="task-actions">
                    <Checkbox
                        checked={taskObj.completed}
                        onChange={handleComplete}
                        color="primary"
                    />
                    <Button variant="contained" color="primary" onClick={toggle}>Edit</Button>
                    <Button variant="contained" color="secondary" onClick={handleDelete} style={{ marginLeft: '10px' }}>Delete</Button>
                </div>
            </div>
            <EditTask modal={modal} toggle={toggle} updateTask={updateTask} taskObj={taskObj} />
        </Card>
    );
};

export default CardComponent;
