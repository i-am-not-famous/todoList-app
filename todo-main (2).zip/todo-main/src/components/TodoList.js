import React, { useEffect, useState } from 'react';
import { Button, Typography, Container } from '@mui/material';
import CreateTask from '../modals/CreateTask';
import CardComponent from './Card';
import '../styles/TodoList.css';

const TodoList = () => {
    const [modal, setModal] = useState(false);
    const [taskList, setTaskList] = useState([]);

    useEffect(() => {
        let arr = localStorage.getItem("taskList");
        if (arr) {
            let obj = JSON.parse(arr);
            setTaskList(obj);
        }
    }, []);

    const deleteTask = (index) => {
        let tempList = taskList;
        tempList.splice(index, 1);
        localStorage.setItem("taskList", JSON.stringify(tempList));
        setTaskList(tempList);
        window.location.reload();
    }

    const updateListArray = (obj, index) => {
        let tempList = taskList;
        tempList[index] = obj;
        localStorage.setItem("taskList", JSON.stringify(tempList));
        setTaskList(tempList);
        window.location.reload();
    }

    const toggle = () => {
        setModal(!modal);
    }

    const saveTask = (taskObj) => {
        let tempList = taskList;
        tempList.push(taskObj);
        localStorage.setItem("taskList", JSON.stringify(tempList));
        setTaskList(taskList);
        setModal(false);
    }

    const getCategoryColor = (category) => {
        switch (category) {
            case 'Work':
                return '#FFD700'; // 금색
            case 'Study':
                return '#87CEEB'; // 하늘색
            case 'Personal':
                return '#FFA07A'; // 살구색
            default:
                return '#A5A5A5'; // 기본 회색
        }
    }

    return (
        <Container>
            <div className="header">
                <Typography variant="h3" component="h1" gutterBottom>
                    Todo List
                </Typography>
                <Button variant="contained" color="primary" className="btn-create" onClick={() => setModal(true)}>
                    Create Task
                </Button>
            </div>
            <div className="task-container">
                {taskList && taskList.map((obj, index) => (
                    <CardComponent
                        key={index}
                        taskObj={obj}
                        index={index}
                        deleteTask={deleteTask}
                        updateListArray={updateListArray}
                        getCategoryColor={getCategoryColor} // getCategoryColor 함수 전달
                    />
                ))}
            </div>
            <CreateTask toggle={toggle} modal={modal} save={saveTask} />
        </Container>
    );
};

export default TodoList;
