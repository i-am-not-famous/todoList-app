import React, { useState } from 'react';
import { Card, CardHeader, CardContent, Button, Typography } from '@mui/material';
import EditTask from '../modals/EditTask';

const TaskCard = ({ taskObj, index, deleteTask, updateListArray }) => {
    const [modal, setModal] = useState(false);

    const colors = [
        { primaryColor: "#5D93E1", secondaryColor: "#ECF3FC" },
        { primaryColor: "#F9D288", secondaryColor: "#FEFAF1" },
        { primaryColor: "#5DC250", secondaryColor: "#F2FAF1" },
        { primaryColor: "#F48687", secondaryColor: "#FDF1F1" },
        { primaryColor: "#B964F7", secondaryColor: "#F3F0FD" }
    ];

    const toggle = () => {
        setModal(!modal);
    }

    const updateTask = (obj) => {
        updateListArray(obj, index);
    }

    const handleDelete = () => {
        deleteTask(index);
    }

    return (
        <Card sx={{ mb: 2, position: 'relative', bgcolor: colors[index % 5].secondaryColor }}>
            <CardHeader
                sx={{ bgcolor: colors[index % 5].primaryColor }}
                title={taskObj.Name}
            />
            <CardContent>
                <Typography variant="body2" color="textSecondary" component="p">
                    {taskObj.Description}
                </Typography>
                <div style={{ position: 'absolute', top: '10px', right: '10px' }}>
                    <Button variant="contained" color="primary" onClick={() => setModal(true)}>
                        Edit
                    </Button>
                    <Button variant="contained" color="secondary" onClick={handleDelete} sx={{ ml: 1 }}>
                        Delete
                    </Button>
                </div>
            </CardContent>
            <EditTask modal={modal} toggle={toggle} updateTask={updateTask} taskObj={taskObj} />
        </Card>
    );
};

export default TaskCard;
