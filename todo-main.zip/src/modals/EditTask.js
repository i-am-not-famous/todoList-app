import React, { useState, useEffect } from 'react';
import { Modal, Box, TextField, Button } from '@mui/material';

const EditTask = ({ modal, toggle, updateTask, taskObj }) => {
    const [taskName, setTaskName] = useState('');
    const [taskDescription, setTaskDescription] = useState('');

    useEffect(() => {
        setTaskName(taskObj.Name);
        setTaskDescription(taskObj.Description);
    }, [taskObj]);

    const handleUpdate = () => {
        let tempObj = {};
        tempObj['Name'] = taskName;
        tempObj['Description'] = taskDescription;
        updateTask(tempObj);
    }

    return (
        <Modal
            open={modal}
            onClose={toggle}
        >
            <Box sx={{ ...style, width: 400 }}>
                <h2>Edit Task</h2>
                <TextField 
                    label="Task Name"
                    fullWidth
                    margin="normal"
                    value={taskName}
                    onChange={(e) => setTaskName(e.target.value)}
                />
                <TextField
                    label="Description"
                    fullWidth
                    margin="normal"
                    multiline
                    rows={4}
                    value={taskDescription}
                    onChange={(e) => setTaskDescription(e.target.value)}
                />
                <Button variant="contained" color="primary" onClick={handleUpdate}>
                    Update
                </Button>
            </Box>
        </Modal>
    );
};

export default EditTask;

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
};
